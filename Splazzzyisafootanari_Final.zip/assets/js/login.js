
function verifyCode() {
    const code = document.getElementById("codeInput").value.trim();
    if (localStorage.getItem("used_" + code)) {
        document.getElementById("errorMsg").textContent = "This code has already been used.";
    } else if (validCodes.has(code)) {
        localStorage.setItem("used_" + code, "true");
        window.location.href = "home.html";
    } else {
        document.getElementById("errorMsg").textContent = "Invalid code.";
    }
}
